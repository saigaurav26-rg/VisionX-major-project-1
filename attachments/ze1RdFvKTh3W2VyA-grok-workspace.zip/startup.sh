#!/bin/bash
set -eu
cd /workspace

if curl -sf -o /dev/null http://127.0.0.1:8080/; then
  exit 0
fi

npm run dev >/tmp/visionx-dev.log 2>&1 &
i=0
while [ "$i" -lt 90 ]; do
  if curl -sf -o /dev/null http://127.0.0.1:8080/; then
    exit 0
  fi
  i=$((i + 1))
  sleep 1
done
echo "VisionX dev server failed to start" >&2
tail -n 80 /tmp/visionx-dev.log >&2 || true
exit 1
