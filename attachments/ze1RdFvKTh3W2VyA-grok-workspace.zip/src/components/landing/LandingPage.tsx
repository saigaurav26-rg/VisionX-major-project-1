"use client";

import { useState, useEffect } from "react";
import { CustomCursor } from "@/components/ui/custom-cursor";
import { LoadingScreen } from "./LoadingScreen";
import { LandingNavbar } from "./Navbar";
import { Hero } from "./Hero";
import { About } from "./About";
import { ProblemSolution } from "./ProblemSolution";
import { Technology } from "./Technology";
import { Demo } from "./Demo";
import { RestorationXRayPreview } from "./RestorationXRayPreview";
import { Footer } from "./Footer";
import { BackgroundParticles } from "@/components/ui/background-particles";

export function LandingPage() {
  const [loadingComplete, setLoadingComplete] = useState(false);
  const [showLanding, setShowLanding] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowLanding(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  const handleLoadingComplete = () => {
    setLoadingComplete(true);
  };

  if (!loadingComplete) {
    return (
      <LoadingScreen onComplete={handleLoadingComplete} />
    );
  }

  return (
    <div className="min-h-screen bg-black relative">
      <BackgroundParticles particleCount={30} speed={0.08} className="fixed inset-0" />
      
      <CustomCursor />
      
      {showLanding && (
        <>
          <LandingNavbar />
          
          <main id="main-content">
            <Hero />
            <About />
            <ProblemSolution />
            <Technology />
            <Demo />
            <RestorationXRayPreview />
            <Footer />
          </main>
        </>
      )}
    </div>
  );
}