"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { BackgroundParticles } from "@/components/ui/background-particles";

interface LoadingScreenProps {
  onComplete: () => void;
  duration?: number;
}

const STAGES = [
  { progress: 0, label: "Initializing VisionX" },
  { progress: 20, label: "Loading restoration engine" },
  { progress: 45, label: "Preparing visual system" },
  { progress: 70, label: "Loading interface" },
  { progress: 90, label: "VisionX ready" },
];

export function LoadingScreen({ onComplete, duration = 2800 }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState(STAGES[0].label);
  const [showContent, setShowContent] = useState(false);
  const [fadeOut, setFadeOut] = useState(false);
  const startRef = useRef<number | null>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const prefersReduced = mediaQuery.matches;

    const animate = (timestamp: number) => {
      if (!startRef.current) startRef.current = timestamp;
      const elapsed = timestamp - startRef.current;
      const p = prefersReduced ? 1 : Math.min(elapsed / duration, 1);

      setProgress(Math.round(p * 100));

      const currentStage = STAGES.findLast((s) => p * 100 >= s.progress);
      if (currentStage) setStage(currentStage.label);

      if (p < 1) {
        rafRef.current = requestAnimationFrame(animate);
      } else {
        setShowContent(true);
        setTimeout(() => {
          setFadeOut(true);
          setTimeout(() => onComplete(), 600);
        }, 300);
      }
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [duration, onComplete]);

  return (
    <div
      className={cn(
        "fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-black",
        fadeOut && "animate-fade-out"
      )}
      role="status"
      aria-label="Loading VisionX"
    >
      <BackgroundParticles particleCount={25} speed={0.08} />

      <div className="relative z-10 flex flex-col items-center gap-8 text-white">
        <div className="flex flex-col items-center gap-4">
          <span className="text-4xl lg:text-6xl font-semibold tracking-tight letter-spacing-[0.08em]">
            VISIONX
          </span>
          <span className="text-xs uppercase tracking-[0.3em] text-white/50">INITIALIZING...</span>
        </div>

        <div className="relative w-full max-w-md">
          <div className="h-1 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-white rounded-full transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between mt-3 text-xs font-mono text-white/60">
            <span>0%</span>
            <span>{progress}%</span>
            <span>100%</span>
          </div>
        </div>

        <div className="text-xs text-white/40 font-mono min-h-[1.25rem] text-center">
          {stage}
        </div>
      </div>

      <style jsx global>{`
        @keyframes fade-out {
          from { opacity: 1; }
          to { opacity: 0; visibility: hidden; }
        }
        .animate-fade-out {
          animation: fade-out 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
}