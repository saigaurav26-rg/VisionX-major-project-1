"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

interface RainDrop {
  x: number;
  y: number;
  length: number;
  speed: number;
  opacity: number;
  width: number;
}

interface RainProps {
  className?: string;
  dropCount?: number;
  color?: string;
  enableLightning?: boolean;
  intensity?: "light" | "medium" | "heavy";
}

export function RainBackground({
  className,
  dropCount = 80,
  color = "oklch(1 0 0 / 0.15)",
  enableLightning = true,
  intensity = "light",
}: RainProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);
  const dropsRef = useRef<RainDrop[]>([]);
  const lightningRef = useRef<{ active: boolean; progress: number; x: number }>({
    active: false,
    progress: 0,
    x: 0,
  });
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReducedMotion(mediaQuery.matches);
    const handler = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
    mediaQuery.addEventListener("change", handler);
    return () => mediaQuery.removeEventListener("change", handler);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resize = () => {
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (rect) {
        const dpr = window.devicePixelRatio || 1;
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        canvas.style.width = `${rect.width}px`;
        canvas.style.height = `${rect.height}px`;
        setDimensions({ width: canvas.width, height: canvas.height });

        if (dropsRef.current.length === 0) {
          initDrops(canvas.width, canvas.height);
        }
      }
    };

    const initDrops = (w: number, h: number) => {
      const count = intensity === "heavy" ? dropCount * 2 : intensity === "medium" ? dropCount * 1.5 : dropCount;
      dropsRef.current = Array.from({ length: Math.floor(count) }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        length: 8 + Math.random() * 20,
        speed: 4 + Math.random() * 8,
        opacity: 0.08 + Math.random() * 0.12,
        width: 0.5 + Math.random() * 1,
      }));
    };

    resize();
    window.addEventListener("resize", resize);

    const animate = () => {
      if (prefersReducedMotion) return;

      const canvas = canvasRef.current;
      if (!canvas) return;

      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const { width, height } = dimensions;
      if (width === 0 || height === 0) {
        animationRef.current = requestAnimationFrame(animate);
        return;
      }

      ctx.clearRect(0, 0, width, height);

      ctx.strokeStyle = color;
      ctx.lineCap = "round";

      dropsRef.current.forEach((drop) => {
        ctx.globalAlpha = drop.opacity;
        ctx.lineWidth = drop.width * (window.devicePixelRatio || 1);
        ctx.beginPath();
        ctx.moveTo(drop.x, drop.y);
        ctx.lineTo(drop.x, drop.y + drop.length);
        ctx.stroke();

        drop.y += drop.speed;
        drop.x += Math.sin(drop.y * 0.01) * 0.3;

        if (drop.y > height + drop.length) {
          drop.y = -drop.length;
          drop.x = Math.random() * width;
        }
      });

      if (enableLightning && !lightningRef.current.active && Math.random() < 0.0008) {
        lightningRef.current = {
          active: true,
          progress: 0,
          x: Math.random() * width,
        };
      }

      if (lightningRef.current.active) {
        lightningRef.current.progress += 0.15;
        if (lightningRef.current.progress >= 1) {
          lightningRef.current.active = false;
        } else {
          const intensity = Math.sin(lightningRef.current.progress * Math.PI);
          const gradient = ctx.createRadialGradient(
            lightningRef.current.x,
            0,
            0,
            lightningRef.current.x,
            0,
            width * 1.5
          );
          gradient.addColorStop(0, `oklch(1 0 0 / ${0.15 * intensity})`);
          gradient.addColorStop(0.5, `oklch(1 0 0 / ${0.05 * intensity})`);
          gradient.addColorStop(1, "oklch(1 0 0 / 0)");

          ctx.fillStyle = gradient;
          ctx.fillRect(0, 0, width, height);
        }
      }

      ctx.globalAlpha = 1;
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener("resize", resize);
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [color, dropCount, enableLightning, intensity, prefersReducedMotion, dimensions]);

  return (
    <canvas
      ref={canvasRef}
      className={cn("fixed inset-0 pointer-events-none", className)}
      aria-hidden="true"
    />
  );
}

interface RainHeroProps {
  className?: string;
}

export function RainHero({ className }: RainHeroProps) {
  return (
    <div className={cn("relative overflow-hidden", className)}>
      <div className="absolute inset-0 bg-black" />
      <RainBackground
        dropCount={60}
        color="oklch(1 0 0 / 0.12)"
        intensity="light"
        enableLightning={true}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/40 pointer-events-none" />
    </div>
  );
}