"use client";

import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  opacity: number;
  color: string;
}

interface BackgroundParticlesProps {
  className?: string;
  particleCount?: number;
  colors?: string[];
  speed?: number;
  connectDistance?: number;
  enableConnections?: boolean;
}

const DEFAULT_COLORS = [
  "oklch(1 0 0 / 0.08)",
  "oklch(0.85 0.16 95 / 0.08)",
  "oklch(0.72 0.10 230 / 0.05)",
];

export function BackgroundParticles({
  className,
  particleCount = 40,
  colors = DEFAULT_COLORS,
  speed = 0.15,
  connectDistance = 180,
  enableConnections = true,
}: BackgroundParticlesProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const sizeRef = useRef({ width: 0, height: 0 });
  const reducedRef = useRef(false);
  const colorsRef = useRef(colors);
  colorsRef.current = colors;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    reducedRef.current = mediaQuery.matches;
    const onMotion = (e: MediaQueryListEvent) => {
      reducedRef.current = e.matches;
    };
    mediaQuery.addEventListener("change", onMotion);

    const initParticles = (w: number, h: number) => {
      const palette = colorsRef.current.length ? colorsRef.current : DEFAULT_COLORS;
      particlesRef.current = Array.from({ length: particleCount }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * speed * 0.5,
        vy: (Math.random() - 0.5) * speed * 0.5,
        radius: 0.5 + Math.random() * 1.5,
        opacity: 0.05 + Math.random() * 0.15,
        color: palette[Math.floor(Math.random() * palette.length)],
      }));
    };

    const resize = () => {
      const parent = canvas.parentElement;
      const rect = parent?.getBoundingClientRect();
      const cssW = Math.max(1, rect?.width || window.innerWidth);
      const cssH = Math.max(1, rect?.height || window.innerHeight);
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(1, Math.floor(cssW * dpr));
      const h = Math.max(1, Math.floor(cssH * dpr));
      if (canvas.width === w && canvas.height === h) return;
      canvas.width = w;
      canvas.height = h;
      canvas.style.width = `${cssW}px`;
      canvas.style.height = `${cssH}px`;
      sizeRef.current = { width: w, height: h };
      if (particlesRef.current.length === 0) {
        initParticles(w, h);
      }
    };

    resize();
    window.addEventListener("resize", resize, { passive: true });

    const animate = () => {
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const { width, height } = sizeRef.current;
      if (width === 0 || height === 0) {
        animationRef.current = requestAnimationFrame(animate);
        return;
      }

      ctx.clearRect(0, 0, width, height);

      if (!reducedRef.current) {
        const particles = particlesRef.current;
        if (enableConnections) {
          const maxDist = connectDistance * (window.devicePixelRatio || 1);
          for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
              const p1 = particles[i];
              const p2 = particles[j];
              const dx = p1.x - p2.x;
              const dy = p1.y - p2.y;
              const dist = Math.sqrt(dx * dx + dy * dy);
              if (dist < maxDist) {
                const opacity = (1 - dist / maxDist) * 0.03;
                ctx.strokeStyle = `oklch(1 0 0 / ${opacity})`;
                ctx.lineWidth = 0.3;
                ctx.beginPath();
                ctx.moveTo(p1.x, p1.y);
                ctx.lineTo(p2.x, p2.y);
                ctx.stroke();
              }
            }
          }
        }

        particles.forEach((p) => {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < -p.radius) p.x = width + p.radius;
          if (p.x > width + p.radius) p.x = -p.radius;
          if (p.y < -p.radius) p.y = height + p.radius;
          if (p.y > height + p.radius) p.y = -p.radius;
          ctx.globalAlpha = p.opacity;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius * (window.devicePixelRatio || 1), 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.globalAlpha = 1;
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener("resize", resize);
      mediaQuery.removeEventListener("change", onMotion);
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [particleCount, speed, connectDistance, enableConnections]);

  return (
    <canvas
      ref={canvasRef}
      className={cn("pointer-events-none", className)}
      aria-hidden="true"
    />
  );
}

export function GlobalBackground({ className }: { className?: string }) {
  return (
    <div className={cn("fixed inset-0 pointer-events-none", className)}>
      <BackgroundParticles particleCount={35} speed={0.12} />
    </div>
  );
}
