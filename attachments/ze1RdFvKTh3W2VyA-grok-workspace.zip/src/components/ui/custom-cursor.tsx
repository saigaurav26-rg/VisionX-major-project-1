"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

interface CustomCursorProps {
  enabled?: boolean;
}

function asElement(target: EventTarget | null): Element | null {
  if (!target) return null;
  if (target instanceof Element) return target;
  if (typeof Text !== "undefined" && target instanceof Text) {
    return target.parentElement;
  }
  return null;
}

export function CustomCursor({ enabled = true }: CustomCursorProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef<number | null>(null);
  const targetRef = useRef({ x: 0, y: 0 });
  const currentRef = useRef({ x: 0, y: 0 });
  const ringSizeRef = useRef(24);
  const targetRingSizeRef = useRef(24);
  const hoveringRef = useRef(false);
  const clickingRef = useRef(false);
  const [mounted, setMounted] = useState(false);
  const [visible, setVisible] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    setMounted(true);
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mediaQuery.matches);
    setIsTouch("ontouchstart" in window || navigator.maxTouchPoints > 0);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener("change", handler);
    return () => mediaQuery.removeEventListener("change", handler);
  }, []);

  useEffect(() => {
    if (!enabled || reducedMotion || isTouch) return;

    const applyHover = (type: "default" | "button" | "image" | "link" | "none") => {
      if (type === "none") {
        hoveringRef.current = false;
        targetRingSizeRef.current = 24;
        if (labelRef.current) labelRef.current.style.opacity = "0";
        return;
      }
      hoveringRef.current = true;
      if (type === "button") targetRingSizeRef.current = 40;
      else if (type === "link") targetRingSizeRef.current = 36;
      else if (type === "image") {
        targetRingSizeRef.current = 38;
        if (labelRef.current) labelRef.current.style.opacity = "1";
      } else targetRingSizeRef.current = 28;
      if (type !== "image" && labelRef.current) labelRef.current.style.opacity = "0";
    };

    const handleMove = (e: MouseEvent) => {
      targetRef.current.x = e.clientX;
      targetRef.current.y = e.clientY;
      setVisible(true);
    };

    const handleMouseDown = () => {
      clickingRef.current = true;
      if (ringRef.current) ringRef.current.style.opacity = "0.55";
    };
    const handleMouseUp = () => {
      clickingRef.current = false;
      if (ringRef.current) ringRef.current.style.opacity = hoveringRef.current ? "1" : "0.7";
    };

    const handleMouseOver = (e: Event) => {
      const el = asElement(e.target);
      if (!el || typeof el.closest !== "function") {
        applyHover("none");
        return;
      }
      if (el.closest("button, [role='button']")) applyHover("button");
      else if (el.closest("a")) applyHover("link");
      else if (el.closest("img")) applyHover("image");
      else applyHover("default");
    };

    window.addEventListener("mousemove", handleMove, { passive: true });
    window.addEventListener("mousedown", handleMouseDown);
    window.addEventListener("mouseup", handleMouseUp);
    document.addEventListener("mouseover", handleMouseOver, true);

    const animate = () => {
      currentRef.current.x += (targetRef.current.x - currentRef.current.x) * 0.18;
      currentRef.current.y += (targetRef.current.y - currentRef.current.y) * 0.18;
      ringSizeRef.current += (targetRingSizeRef.current - ringSizeRef.current) * 0.22;
      const node = rootRef.current;
      if (node) {
        node.style.transform = `translate3d(${currentRef.current.x}px, ${currentRef.current.y}px, 0) translate(-50%, -50%)`;
      }
      if (ringRef.current) {
        const size = ringSizeRef.current;
        ringRef.current.style.width = `${size}px`;
        ringRef.current.style.height = `${size}px`;
      }
      rafRef.current = requestAnimationFrame(animate);
    };
    rafRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener("mousemove", handleMove);
      window.removeEventListener("mousedown", handleMouseDown);
      window.removeEventListener("mouseup", handleMouseUp);
      document.removeEventListener("mouseover", handleMouseOver, true);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [enabled, reducedMotion, isTouch]);

  useEffect(() => {
    if (!visible || reducedMotion || isTouch) return;
    document.documentElement.classList.add("custom-cursor-enabled");
    return () => document.documentElement.classList.remove("custom-cursor-enabled");
  }, [visible, reducedMotion, isTouch]);

  if (!mounted || !enabled || reducedMotion || isTouch || !visible) {
    return null;
  }

  return (
    <div
      ref={rootRef}
      className={cn("fixed pointer-events-none z-[9999] left-0 top-0")}
      style={{ willChange: "transform" }}
      aria-hidden="true"
    >
      <div
        ref={ringRef}
        className="absolute rounded-full border border-yellow-400/70"
        style={{
          width: 24,
          height: 24,
          transform: "translate(-50%, -50%)",
          opacity: 0.7,
        }}
      />
      <div
        className="absolute rounded-full bg-white"
        style={{
          width: 4,
          height: 4,
          transform: "translate(-50%, -50%)",
        }}
      />
      <div
        ref={labelRef}
        className="absolute text-white text-[10px] font-mono uppercase tracking-wider whitespace-nowrap pointer-events-none"
        style={{
          transform: "translate(-50%, calc(-50% - 28px))",
          opacity: 0,
        }}
      >
        VIEW
      </div>
    </div>
  );
}

export function CursorProvider({ children }: { children: React.ReactNode }) {
  return (
    <>
      {children}
      <CustomCursor />
    </>
  );
}
