module.exports = [
"[project]/.next-internal/server/app/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_app_page_actions_0u_ujkh.js.map