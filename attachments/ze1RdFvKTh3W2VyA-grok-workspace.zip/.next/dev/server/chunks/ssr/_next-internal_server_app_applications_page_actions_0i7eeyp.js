module.exports = [
"[project]/.next-internal/server/app/applications/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_applications_page_actions_0i7eeyp.js.map