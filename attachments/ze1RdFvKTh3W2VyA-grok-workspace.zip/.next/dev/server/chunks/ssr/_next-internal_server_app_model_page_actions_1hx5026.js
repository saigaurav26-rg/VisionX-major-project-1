module.exports = [
"[project]/.next-internal/server/app/model/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=_next-internal_server_app_model_page_actions_1hx5026.js.map