var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/node_modules_next_0zy6_dr._.js")
R.c("server/chunks/[root-of-the-server]__0cp_kkc._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/middleware.js { INNER_MIDDLEWARE_MODULE => \"[project]/proxy.ts [middleware] (ecmascript)\" } [middleware] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/middleware.js { INNER_MIDDLEWARE_MODULE => \"[project]/proxy.ts [middleware] (ecmascript)\" } [middleware] (ecmascript)").exports
