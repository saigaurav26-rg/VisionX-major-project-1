globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_14ibvna._.js",
      "static/chunks/node_modules_next_dist_shared_lib_196_nl_._.js",
      "static/chunks/node_modules_next_dist_client_16lnmlo._.js",
      "static/chunks/node_modules_next_dist_1gdrd03._.js",
      "static/chunks/node_modules_next_app_0yrdk3r.js",
      "static/chunks/[next]_entry_page-loader_ts_0z3haqk._.js",
      "static/chunks/node_modules_react-dom_0kla17-._.js",
      "static/chunks/node_modules_10e2-xo._.js",
      "static/chunks/[root-of-the-server]__0l4r13l._.js",
      "static/chunks/pages__app_0du2_q-._.js",
      "static/chunks/turbopack-pages__app_0e7z0ug._.js"
    ],
    "/_error": [
      "static/chunks/node_modules_next_dist_compiled_14ibvna._.js",
      "static/chunks/node_modules_next_dist_shared_lib_1vsvqbg._.js",
      "static/chunks/node_modules_next_dist_client_16lnmlo._.js",
      "static/chunks/node_modules_next_dist_1atto1n._.js",
      "static/chunks/[next]_entry_page-loader_ts_1aoli7m._.js",
      "static/chunks/node_modules_react-dom_0kla17-._.js",
      "static/chunks/node_modules_10e2-xo._.js",
      "static/chunks/[root-of-the-server]__02sxxph._.js",
      "static/chunks/pages__error_0du2_q-._.js",
      "static/chunks/turbopack-pages__error_1g3qll_._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [
    "static/development/_buildManifest.js",
    "static/development/_ssgManifest.js",
    "static/development/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1di75ot._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js",
    "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js",
    "static/chunks/node_modules_next_dist_compiled_1amofcm._.js",
    "static/chunks/node_modules_next_dist_client_0_90u2t._.js",
    "static/chunks/node_modules_next_dist_1e8vcs8._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqw._.js",
    "static/chunks/_1anvha4._.js",
    "static/chunks/turbopack-_08bm286._.js"
  ],
  "rootMainFilesTree": {
    "/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1di75ot._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcm._.js",
      "static/chunks/node_modules_next_dist_client_0_90u2t._.js",
      "static/chunks/node_modules_next_dist_1e8vcs8._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqw._.js",
      "static/chunks/_1anvha4._.js",
      "static/chunks/turbopack-_08bm286._.js",
      "static/chunks/_219uq1s._.js"
    ],
    "/history/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1di75ot._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcm._.js",
      "static/chunks/node_modules_next_dist_client_0_90u2t._.js",
      "static/chunks/node_modules_next_dist_1e8vcs8._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqw._.js",
      "static/chunks/_1anvha4._.js",
      "static/chunks/turbopack-_08bm286._.js",
      "static/chunks/_1f2-l26._.js"
    ],
    "/docs/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1di75ot._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcm._.js",
      "static/chunks/node_modules_next_dist_client_0_90u2t._.js",
      "static/chunks/node_modules_next_dist_1e8vcs8._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqw._.js",
      "static/chunks/_1anvha4._.js",
      "static/chunks/turbopack-_08bm286._.js",
      "static/chunks/_0tggzfw._.js"
    ],
    "/settings/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1di75ot._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcm._.js",
      "static/chunks/node_modules_next_dist_client_0_90u2t._.js",
      "static/chunks/node_modules_next_dist_1e8vcs8._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqw._.js",
      "static/chunks/_1anvha4._.js",
      "static/chunks/turbopack-_08bm286._.js",
      "static/chunks/_0k447k3._.js"
    ],
    "/app/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1di75ot._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcm._.js",
      "static/chunks/node_modules_next_dist_client_0_90u2t._.js",
      "static/chunks/node_modules_next_dist_1e8vcs8._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqw._.js",
      "static/chunks/_1anvha4._.js",
      "static/chunks/turbopack-_08bm286._.js",
      "static/chunks/_1670ime._.js"
    ],
    "/dashboard/page": [
      "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1di75ot._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_090k2jm.js",
      "static/chunks/node_modules_next_dist_compiled_react-dom_096_9a-._.js",
      "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_164kp-6._.js",
      "static/chunks/node_modules_next_dist_compiled_1amofcm._.js",
      "static/chunks/node_modules_next_dist_client_0_90u2t._.js",
      "static/chunks/node_modules_next_dist_1e8vcs8._.js",
      "static/chunks/node_modules_@swc_helpers_cjs_1r9vbqw._.js",
      "static/chunks/_1anvha4._.js",
      "static/chunks/turbopack-_08bm286._.js",
      "static/chunks/_1dh94un._.js"
    ]
  },
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
