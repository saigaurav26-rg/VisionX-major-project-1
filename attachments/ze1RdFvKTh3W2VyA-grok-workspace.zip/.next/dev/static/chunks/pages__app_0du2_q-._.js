(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_dist_compiled_14ibvna._.js","static/chunks/node_modules_next_dist_shared_lib_196_nl_._.js","static/chunks/node_modules_next_dist_client_16lnmlo._.js","static/chunks/node_modules_next_dist_1gdrd03._.js","static/chunks/node_modules_next_app_0yrdk3r.js","static/chunks/[next]_entry_page-loader_ts_0z3haqk._.js","static/chunks/node_modules_react-dom_0kla17-._.js","static/chunks/node_modules_10e2-xo._.js","static/chunks/[root-of-the-server]__0l4r13l._.js"],
    source: "entry"
});
