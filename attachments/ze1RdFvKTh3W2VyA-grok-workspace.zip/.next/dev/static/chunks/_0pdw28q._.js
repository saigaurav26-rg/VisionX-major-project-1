(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__04kpziu._.css","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0q79z23._.js","static/chunks/node_modules_zod_v4_classic_0qgufeu._.js","static/chunks/node_modules_zod_v4_core_15b2lfp._.js","static/chunks/node_modules_zod_v4_locales_1-ided7._.js","static/chunks/node_modules_0whhy9z._.js","static/chunks/src_12wzckn._.js","static/chunks/_1vomqio._.js"],
    source: "entry"
});
