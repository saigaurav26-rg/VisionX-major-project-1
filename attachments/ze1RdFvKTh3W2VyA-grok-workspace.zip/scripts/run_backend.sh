#!/bin/bash
cd /home/user/project
exec python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 > /tmp/visionx-backend.log 2>&1